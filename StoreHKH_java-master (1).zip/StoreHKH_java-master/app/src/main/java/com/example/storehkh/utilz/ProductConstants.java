package com.example.storehkh.utilz;

public class ProductConstants {
    public final static int NEW_PRODUCT = 1;
    public final static int PORPULAR_PRODUCT = 2;
    public final static int SHOW_ALL_PRODUCT =3;
}
